public class Battleship extends ConsoleProgram
{
    public void run()
    {
        // Copy over your Battleship class here
        
        // Then add extensions to make the game better!
    }
}