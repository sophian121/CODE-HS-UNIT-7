public class Player
{
    // Copy over your Player class here
}