public class Location
{
    // Copy over your Location class here
}