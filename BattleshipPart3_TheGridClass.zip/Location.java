public class Location
{
    // Copy your Location class from part 2.
}