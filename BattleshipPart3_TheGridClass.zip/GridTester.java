public class GridTester extends ConsoleProgram
{
    public void run()
    {
        // Your test code here.
    }
}