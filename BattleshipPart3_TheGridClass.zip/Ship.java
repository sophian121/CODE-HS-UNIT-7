public class Ship
{
    // Copy your ship class from Part 1.
}