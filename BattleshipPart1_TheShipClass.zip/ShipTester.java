public class ShipTester extends ConsoleProgram
{
    public void run()
    {
        // Your test code for the Ship class here.
    }
}