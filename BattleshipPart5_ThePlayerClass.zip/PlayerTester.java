public class PlayerTester extends ConsoleProgram
{
    public void run()
    {
        // Test code here.
    }
}