public class Ship
{
    // Copy over your code for the Ship class here
}