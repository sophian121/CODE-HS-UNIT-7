public class Location
{
    // Copy over your code for the Location class here
}