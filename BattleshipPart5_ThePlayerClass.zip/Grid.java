public class Grid
{
    // Copy over your code for the Grid class here
}