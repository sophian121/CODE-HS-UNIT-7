public class GridTester extends ConsoleProgram
{
    public void run()
    {
        // Start here!
    }
}