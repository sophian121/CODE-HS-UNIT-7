public class Battleship extends ConsoleProgram
{
    public void run()
    {
        // Copy over your Battleship class here
        
        // Then finish the game! Make sure your program is robust
        // it should handle incorrect user input and other edge cases
    }
}