public class Grid
{
    // Copy over your Grid class here
}