public class Player
{
    // Copy over your Player class here
    
    // You may need to make additions to your Player class in order
    // to write your Battleship class
}