public class Ship
{
    // Copy over your Ship class here
}