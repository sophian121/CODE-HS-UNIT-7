public class LocationTester extends ConsoleProgram
{
    public void run()
    {
        // Test out your Location class here!
    }
}